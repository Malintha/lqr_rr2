There are two versions of the LQR. 
1) LQR with 2x1 state space
2) LQR with 4x1 state space

The corresponding executables are non_linear_lqr.m and non_linear_lqr_4x1.m.

Dependencies:
MATLAB
MATLAB Robotics toolbox
MATLAB Control toolbox
ModernRobotics Matlab package (included in mr directory)